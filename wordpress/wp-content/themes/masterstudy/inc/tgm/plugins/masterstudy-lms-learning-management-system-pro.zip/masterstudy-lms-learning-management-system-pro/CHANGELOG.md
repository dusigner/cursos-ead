## Version 2.4.0 June 11
- Scorm zip file uploading fixed
- Email sending for instructor and student fixed
- Visual bugs fixed
- Lesson question time showing for user fixed
- Logout now redirects to login page
- Russian language updated

## Version 1.7.0 June 5, 2020
- Lesson Style Classic added.
- Email Template Manager added.
- Assign Students to Course added.
- Gradebook – Students progress fixes.
- Assignments – Vertical Scroll removed.
- Assignments – Sending Email Notifications bug fixed.
- SCORM – Curriculum disabling issue fixed.

## Version 1.6.1 May 28, 2020
- Minor bug fixes.

## Version 1.6
- May 26, 2020
- New Course Attachments added.
- New Course Finished Statistics added.
- Minor bug fixes.

## Version 1.5
- May 6, 2020
- New Courses Filter added.
- New Instructor menu added.
- Minor bug fixes.

## Version 1.4.7 April 24, 2020
- SCORM Courses integration added.
- Minor bug fixes.

## Version 1.4.6
- April 15, 2020
- Minor bug fixes.

## Version 1.4.5
- March 27, 2020
- ZOOM Conference feature added.

## Version 1.4.4 March 20, 2020
- Google Classroom feature added.
- Minor bug fixes.

## Version 1.4.3 February 25, 2020
- Minor bug fixes.

## Version 1.4.1 December 26, 2019
- Multi-instructors feature added.
- Unique code for certificates feature added (with Code checker WPBakery Page Builder element).
- Instructors can create Course Categories.
- Minor bug fixes.

## Version 1.4.0 December 19, 2019
- Course Bundle feature added.

## Version 1.3.9
- December 10, 2019
- Questions Bank system added.
- Course Affiliate Link feature added.
- Minor bug fixes.

## Version 1.3.8 December 4, 2019
- Points system added.

## Version 1.3.7 November 25, 2019
- Assignments feature added.
- Minor bug fixes.

## Version 1.3.6 November 6, 2019
- Group (Team) Courses feature added.
- Minor bug fixes.

## Version 1.3.5 October 21, 2019
- Forgot Password problem fixed.
- Currency symbol issue fixed.
- Minor bug fixes.

## Version 1.3.4 October 3, 2019
- Lessons Live Streaming feature added.
- Minor bug fixes.

## Version 1.3.3 September 19, 2019
- Drip Content feature added.
- Sequential Lessons feature added.
- The GradeBook feature added.

## Version 1.3.2 September 5, 2019
- Minor bug fixes.

## Version 1.3.1 August 12, 2019
- Added new question types.
- Minor bug fixes.

## Version 1.3 July 18, 2019
- Prerequisites problem fixed.
- WPML Switcher fixed.
- Minor bug fixes.

## Version 1.2 June 18, 2019
- Minor bug fixes.

## Version 1.1 April 25, 2019
- Teacher Course Sales & Earnings Statistics added.
- Automatic Payouts feature added.

## Version 1.0 March 11, 2019
- Release.