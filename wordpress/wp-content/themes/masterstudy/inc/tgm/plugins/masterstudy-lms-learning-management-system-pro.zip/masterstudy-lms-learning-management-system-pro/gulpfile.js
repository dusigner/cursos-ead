var gulp = require('gulp');
var sass = require('gulp-sass');
var autoprefixer = require('gulp-autoprefixer');
const browserSync = require('browser-sync').create();
const watch = require('gulp-watch');
const cssmin = require('gulp-cssmin');
var livereload = require('gulp-livereload');

gulp.task('serve', function () {
    "use strict";
    browserSync.init({
        proxy: "http://lms.loc",
        host: "192.168.0.124",
        port: 3000,
        notify: true,
        ui: {
            port: 3001
        },
        open: false
    });
});

gulp.task('watch', function () {
    livereload.listen();

    watch('./wizard/assets/scss/*.scss').on('change', (e) => {
        gulp.src('./wizard/assets/scss/*.scss')
            .pipe(sass().on('error', sass.logError))
            .pipe(autoprefixer())
            .pipe(cssmin())
            .pipe(gulp.dest('./wizard/assets/css'))
            .pipe(browserSync.stream())
            .pipe(livereload());
    });
});

gulp.task('default', ['watch', 'serve']);