<?php
require_once(STM_LMS_PATH . '/shortcodes/grid.php');